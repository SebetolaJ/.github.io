// Online C++ compiler to run C++ program online
#include <iostream>

using namespace std;

   int main(){
    string sCard,sOutput;
    int iCard,iCount,iTotal,iTotal1;
    iTotal=0;
    iCount=0;
    while(true){
       cin>>sCard;
       if (sCard=="end") {
        break;
       } 
   
        if (sCard[0]=='1'){
            iCard=10;   
       }

      else  if (sCard[0]=='A'){
            iCount=iCount+1;
            iCard=11;

    }
     

   else if (sCard[0]=='K'||sCard[0]=='Q'||sCard[0]=='J'){    //K OR J OR Q
        iCard=10;   
    }
    else{
        
        iCard=sCard[0]-48;
    }
        iTotal=iTotal+iCard;
    }
  
    if (iCount!=0 && iTotal<21){
        iTotal1=iTotal-(iCount*10);
        cout<<iTotal1<<" or "<<iTotal<<endl;
    }
    else if(iCount!=0 && iTotal>21){
         iTotal1=iTotal-(iCount*10)+10;
         iTotal=iTotal-(iCount*10);

        if (iTotal<21 && iTotal1<21){
            cout<<iTotal<<" or "<<iTotal1<<endl;
        }
        else{
             if(iCount==1 and iTotal==21){
                cout<<iTotal<<endl;
             }
             
            else{
                
                 if(iCount==1 and iTotal<21){
                 cout<<iTotal<<endl;
             }else if(iTotal>21){
                cout<<"Bust!"<<endl;}
            }
         }
         
    }else if(iTotal>21){
        cout<<"Bust!"<<endl;
    }
    
    
    else if(iTotal==21){
            cout<<"Blackjack!"<<endl;
    }

    else{
     
    
        cout<<iTotal<<endl;
    
    }

    
    return 0;
}