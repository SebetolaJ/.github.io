#include <iostream>
using namespace std;

int main(){
    string sCard,sCard1,sDealer;
    int iCard,iCard1,iDealer,iTotal,iTotal1;
    
    cin>>sDealer>>sCard>>sCard1;

    if (sCard[0]=='A' or sCard1[0]=='A'){
   if (sCard1[0]=='1'){
            iCard1=10;   
       }

      else  if (sCard1[0]=='A'){
          
            iCard1=11;

    }
     
   else if (sCard1[0]=='K'||sCard1[0]=='Q'||sCard1[0]=='J'){    //K OR J OR Q
        iCard1=10;   
    }
    else{
        
        iCard1=sCard1[0]-48;
    }
        if (sCard[0]=='1'){
            iCard=10;   
       }

      else  if (sCard[0]=='A'){
            iCard=11;

    }
     
   else if (sCard[0]=='K'||sCard[0]=='Q'||sCard[0]=='J'){    //K OR J OR Q
        iCard=10;   
    }
    else{
        
        iCard=sCard[0]-48;
    }
  
        if (sDealer[0]=='1'){
            iDealer=10;   
       }

      else  if (sDealer[0]=='A'){
           
            iDealer=11;

    }
     
   else if (sDealer[0]=='K'||sDealer[0]=='Q'||sDealer[0]=='J'){    //K OR J OR Q
        iDealer=10;   
    }
    else{
        
        iDealer=sDealer[0]-48;
    }

    iTotal=iCard+iCard1;
   if (sCard1[0]=='A' and sCard[0]=='A'){
            iTotal=iTotal-10;
            
   }
        if (iTotal>=19){

            cout<<"Stand"<<endl;
        }
    else if (iTotal>=12 && iTotal<=17){
            cout<<"Hit"<<endl;
        }
    else if (iTotal==18){
            if (iDealer>=9){
            
                cout<<"Hit";
            }
            else{
            cout<<"Stand"<<endl;
        }
        }
        }

        //Second Table
        else{
            if (sCard1[0]=='1'){
            iCard1=10;   
       }

      else  if (sCard1[0]=='A'){
          
            iCard1=11;

    }
     
   else if (sCard1[0]=='K'||sCard1[0]=='Q'||sCard1[0]=='J'){    //K OR J OR Q
        iCard1=10;   
    }
    else{
        
        iCard1=sCard1[0]-48;
    }
        if (sCard[0]=='1'){
            iCard=10;   
       }

      else  if (sCard[0]=='A'){
            iCard=11;

    }
     
   else if (sCard[0]=='K'||sCard[0]=='Q'||sCard[0]=='J'){    //K OR J OR Q
        iCard=10;   
    }
    else{
        
        iCard=sCard[0]-48;
    }
  
        if (sDealer[0]=='1'){
            iDealer=10;   
       }

      else  if (sDealer[0]=='A'){
           
            iDealer=11;

    }
     
   else if (sDealer[0]=='K'||sDealer[0]=='Q'||sDealer[0]=='J'){    //K OR J OR Q
        iDealer=10;   
    }
    else{
        
        iDealer=sDealer[0]-48;
    }

    iTotal=iCard+iCard1;

    if (iTotal>=4 and iTotal<=11 and iDealer>=2){
        cout<<"Hit"<<endl;
    }
    else if(iDealer>=7 and iTotal>=12 and iTotal<=16){
        cout<<"Hit"<<endl;
    }
    else if(iTotal>=13 and iDealer>=2 and iDealer<=6){
        cout<<"Stand"<<endl;
    }
    else if(iTotal==12 and (iDealer>=2 and iDealer<=3 or iDealer>=7)){
        cout<<"Hit"<<endl;
    }
    else{
        cout<<"Stand"<<endl;
    }


        }
        
return 0;
}