#include <iostream>
using namespace std;

   int main(){
    string sCard;
    int iCard,iTotal;
    iTotal=0;
    cin>>sCard;
  
    while (sCard!="end"){
        

       cin>>sCard;  

       if (sCard=='A'){
            iCard=10;

       }

       if (sCard[0]=='1'){
            iCard=10;   
       }

   else if (sCard[0]=='K'||sCard[0]=='Q'||sCard[0]=='J'){    //K OR J OR Q
        iCard=10;
      
    }
    else{
        
        iCard=sCard[0]-'0';
    }
    
        iTotal=iTotal+iCard;
    }
    cout<<iTotal<<endl;
    
    return 0;
}
