#include <iostream>;
using namespace std;

int main(){
   string sCard,sCard1;
    string sText="23456789"; //scored according to face value
    string sText1="23456789";
    char cOne,cTwo,cThree;
    int p,z;
    cin>>sCard>>sCard1;

    if (sCard[0]+sCard[1]=='1'+'0'&& sCard1[0]+sCard1[1]=='1'+'0' ){
      cout<<"20";  
    }
    for (int b=0;b<sText1.length();b=b+1){
        cTwo=char(sText1[b]);
        int z=int(cTwo)-48;
        
    //nested for loop to avoid logical operations
        for (int i=0;i<sText.length();i=i+1){
            cThree=char(sText[i]);
            int p=int(cThree)-48;
         
    if (sCard[0]==cThree && sCard1[0]==cTwo){
                cout<<z+p<<endl;
    }  
        }
    }        
    
    if (sCard[0]=='K'||sCard[0]=='Q'||sCard[0]=='J'){
        if (sCard1[0]=='K'||sCard1[0]=='Q'||sCard1[0]=='J'){
            cout<<"20"<<endl;
     }
     }
    if (sCard[0]+sCard[1]=='1'+'0'&& sCard1[0]=='A' ){
      cout<<"Blackjack!";  
     }
     if (sCard1[0]+sCard1[1]=='1'+'0'&& sCard[0]=='A' ){
      cout<<"Blackjack!";
     }
     if (sCard[0]=='A' && sCard1[0]=='A'){
        cout<<"2 or 12"<<endl;
     }

    if   (sCard1[0]=='K'||sCard1[0]=='Q'||sCard1[0]=='J'){
        if (sCard[0]=='A'){ 
            cout<<"Blackjack!"<<endl;
    }
    }
    if (sCard1[0]=='A'){
        if ( sCard[0]=='K'||sCard[0]=='Q'||sCard[0]=='J'){
             cout<<"Blackjack!"<<endl;
    }
    }
     

    for (int i=0;i<sText.length();i=i+1){
        cOne=char(sText[i]);
        int j;
        if (sCard[0]==cOne ||sCard1[0]==cOne){  //Nested if statement to make things easier
            if (sCard1[0]=='A'||sCard[0]=='A'){
                int j=int(cOne)-48;
                cout<<j+1<<" or "<<j+11<<endl;
                }
            
        }
        if (sCard[0]=='K'||sCard[0]=='Q'||sCard[0]=='J'){
          if (sCard[0]==cOne ||sCard1[0]==cOne) {
            int n=int(cOne)-48;
            cout<<n+10<<endl;
           } 
        }
    }
    return 0;
    }
    

     





