#include <iostream>
using namespace std;

int main(){
    string sCard;
    string sText="23456789";
    char c;
    cin>>sCard;
    if (sCard[0]+sCard[1]=='1'+'0'){
      cout<<"10";  
     }
    if (sCard[0]=='A'){
        cout<<"1 or 11"<<endl;
    }
    if (sCard[0]=='K'||sCard[0]=='Q'||sCard[0]=='J'){
        cout<<"10"<<endl;
    
    }

    for (int i=0;i<sText.length();i=i+1){
            c=char(sText[i]);
    if (sCard[0]==c){
        cout<<c<<endl;
    }
   
     }
     
return 0;

}
