sString=input()
ascii=[]
for i in sString:
	result=ord(i)
	ascii.append(result)
for j in ascii:
	print(j, end=" ")

