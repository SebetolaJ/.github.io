iNumber=int(input())
sNew=""
while iNumber!=-1:
    sCode=chr(iNumber)
    sNew=sNew+sCode
    iNumber=int(input())
print(sNew)