sMode=input()
iBase=int(input())
sMessage=input()
iResult=[]

if sMode=="encrypt":
    sMessage=input()
        
    while sMessage!="":
        if iBase<=10:
            for j in sMessage:
                cChar=ord(j)
                iQ=cChar
                iRem = ""
                while iQ!=0:
                    iMod1=str(iQ%iBase)
                    iRem =iMod1 + iRem
                    iQ=iQ//iBase
               
                iResult.append(iRem)
            
        else:
            
            for j in sMessage:
                cChar=ord(j)
                iQ=cChar
                iRem = ""
                while iQ!=0:
                    iMod1=str(iQ%iBase)
                    if int(iMod1)>=10:
                        sChar=chr(int(iMod1)-10+65)
                        iRem=sChar+iRem 
                    else:
                        iRem = iMod1 + iRem
                    iQ=iQ//iBase
            
           
                iResult.append(iRem)
                
            iResult.append("A")
        
else:
    if sMode=="decrypt":
        sNew=sMessage.split()
        sNew2=""
        for z in sNew:
            iResults=int(z,iBase)
            iOrd=chr(iResults)
            sNew2=sNew2+iOrd
        iResult.append(sNew2)
       
for j in iResult:
    print(j,end=" ")
