def decimal(iBase,iNum):
    iTotal=0
    while iNum!=-1:
        
        for j in str(iNum):
            iDigit=j
        for i in range(int(len(str(iNum)))):
            iResult=int(iDigit)*(iBase**i)
            iTotal=iTotal+iResult
        iNum=int(input())
    return iTotal

iBase=int(input())
iNum=int(input())
print(decimal(iBase,iNum))