sMode=input()
iBase=int(input())
sMessage=input()
iResult=[]
if sMode=="encrypt":
    for j in sMessage:
        cChar=ord(j)
        iResult.append(cChar)

for i in iResult:       
    print(i)