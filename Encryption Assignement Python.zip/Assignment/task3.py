iBase=int(input())
iNum=int(input())
iResult=[]
iFinal=[]

if iBase<=10:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
    while iNum!=-1:
        iQ=iNum
        iRem = ""
        if iNum==0:
            iRem="0"
        else:
            while iQ!=0:
                iMod1=str(iQ%iBase)
                iRem = iMod1 + iRem
                iQ=iQ//iBase
    
        iResult.append(iRem)
        iNum=int(input())

else: 
    while iNum!=-1:
        iQ=iNum
        iRem = ""
        if iNum==0:
            iRem="0"
        else:
             while iQ!=0:
                iMod1=str(iQ%iBase)
                if int(iMod1)>=10:
                    sChar=chr(int(iMod1)-10+65)
                    iRem=sChar+iRem 
                else:
                    iRem = iMod1 + iRem
                iQ=iQ//iBase
    
        iResult.append(iRem)
        iNum=int(input())


for j in iResult:
    print(j)
   
