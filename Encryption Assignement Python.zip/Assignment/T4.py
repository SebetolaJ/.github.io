def decimal(iNum,iBase):
  while iNum!="-1":
    iResult=int(str(iNum),iBase)
    iList.append(iResult)
    iNum=input()
  return iList
        
iBase=int(input())
iNum=input()
iList=[]
iAnswer=decimal(iNum,iBase)

for i in iAnswer:
  print(i)